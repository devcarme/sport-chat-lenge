
//Local
// module.exports ={
//     url:"http://localhost:9000/web/"
// }

//Production
module.exports ={
    url:"https://sport-chatlenge.herokuapp.com/web/"
}

